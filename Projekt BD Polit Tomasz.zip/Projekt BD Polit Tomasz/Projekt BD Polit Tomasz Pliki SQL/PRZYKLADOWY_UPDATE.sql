USE royal_family_tree;

UPDATE relations SET Relation_Type = 'Grandfather'
WHERE Relation_ID = 851 AND Primary_Person_ID = 12 AND Secondary_Person_ID = 31