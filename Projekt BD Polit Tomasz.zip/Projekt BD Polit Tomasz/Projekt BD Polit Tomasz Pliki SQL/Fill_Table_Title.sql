INSERT INTO titles VALUES (1, 'King of the United Kingdom and other Commonwealth realms', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Queen of the United Kingdom and other Commonwealth realms', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Consort of the United Kingdom and other Commonwealth realms', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Emiperor of India', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Empress of India', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Prince of Wales', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Princess of Wales', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Duke of Sussex', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Duchess of Sussex', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Duke of Gloucester', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Duchess of Gloucester', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Duke of Kent', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Duchess of Kent ', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Duke of York', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Duchess of York ', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Earl of Wessex', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Countess of Wessex ', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Earl of Forfar', 'Substantive');
INSERT INTO titles VALUES (DEFAULT, 'Countess of Forfar ', 'Substantive');

INSERT INTO titles VALUES (DEFAULT, 'Princess Royal', 'Honorary');